import sys
sys.path.append(".")
from agentic_forecasting import build_graph

def main():
    graph = build_graph()
    for asset in ["AAPL", "BTC/USDT"]:
        out = graph.invoke({"asset": asset})
        print(f"=== {asset} ===")
        print(out.get("backtest_stats", {}))

if __name__ == "__main__":
    main()
