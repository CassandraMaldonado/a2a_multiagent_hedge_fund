# Agentic Forecasting (Skeleton)

This repo gives you a working baseline with:
- Real data connectors (Yahoo, Binance via CCXT, FRED)
- Feature engineering (market + macro transforms)
- Forecasting baselines (ARIMA; Prophet/LSTM optional)
- Risk tools (GARCH, VaR/ES helpers, kill switch)
- Backtest engine (sign-of-forecast with costs/slippage)
- LangGraph orchestration to stitch nodes together
- YAML config

## Quickstart

```bash
pip install -r requirements.txt
python run_demo.py
```

Edit `configs/app.yaml` to turn on macro/GARCH and add your `fred_api_key`.

## Use as a Package
```python
import sys
sys.path.append(".")
import agentic_forecasting as af

graph = af.build_graph()
out = graph.invoke({"asset": "AAPL"})
print(out["backtest_stats"])
```

> For Prophet and TensorFlow/LSTM, install build tools and a compatible TF version for your platform.
