# Data connectors & persistence
# pip install yfinance ccxt fredapi duckdb pyarrow




import pandas as pd
def _normalize_ohlc_columns(df, asset=None):
    cols_needed = {"open","high","low","close","adj close","volume"}
    if isinstance(df.columns, pd.MultiIndex):
        try:
            if cols_needed.issubset(set(map(str.lower, df.columns.get_level_values(0)))):
                df = df.copy(); df.columns = df.columns.get_level_values(0)
            elif cols_needed.issubset(set(map(str.lower, df.columns.get_level_values(1)))):
                df = df.copy(); df.columns = df.columns.get_level_values(1)
            else:
                flattened = []
                for tup in df.columns:
                    pick = None
                    for part in tup:
                        s = str(part).lower()
                        if any(k in s for k in ["open","high","low","close","adj","volume"]):
                            pick = str(part); break
                    flattened.append(pick if pick is not None else "_".join(map(str, tup)))
                df = df.copy(); df.columns = flattened
        except Exception:
            df = df.copy(); df.columns = ["_".join(map(str, c)) if isinstance(c, tuple) else str(c) for c in df.columns]
    else:
        new_cols = []
        for c in df.columns:
            if isinstance(c, tuple):
                pick = None
                for part in c:
                    s = str(part).lower()
                    if any(k in s for k in ["open","high","low","close","adj","volume"]):
                        pick = str(part); break
                new_cols.append(pick if pick is not None else "_".join(map(str, c)))
            else:
                new_cols.append(str(c))
        df = df.copy(); df.columns = new_cols
    ren = {c: str(c).title() for c in df.columns}
    df = df.rename(columns=ren)
    if "Adj Close" not in df.columns and "Adjclose" in df.columns:
        df = df.rename(columns={"Adjclose":"Adj Close"})
    if "Volume" not in df.columns and "Vol" in df.columns:
        df = df.rename(columns={"Vol":"Volume"})
    expected = ["Open","High","Low","Close","Adj Close","Volume"]
    miss = [c for c in expected if c not in df.columns]
    if miss:
        raise ValueError(f"Missing expected OHLCV columns: {miss}. Got: {list(df.columns)}")
    df = df[expected]; df.index.name = "datetime"; return df


from pathlib import Path
import time
import pandas as pd
import duckdb
import yfinance as yf
import ccxt
from fredapi import Fred

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True, parents=True)
DB_PATH = DATA_DIR / "market.duckdb"

def _cache_path(kind:str, key:str)->Path:
    # safe file name: replace slashes, spaces
    safe = key.replace("/", "-").replace(" ", "_")
    return DATA_DIR / f"{kind}_{safe}.parquet"

def _save_parquet(df: pd.DataFrame, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path)

def _read_parquet(path: Path) -> pd.DataFrame | None:
    return pd.read_parquet(path) if path.exists() else None

def fetch_equity_ohlcv(ticker: str, start="2015-01-01", end=None, interval="1d", cache_ttl_min=60):
    """Yahoo Finance OHLCV with on-disk Parquet caching."""
    path = _cache_path("ohlcv_equity", f"{ticker}_{interval}")
    if path.exists() and (time.time() - path.stat().st_mtime) < cache_ttl_min * 60:
        return _read_parquet(path)
    df = yf.download(ticker, start=start, end=end, interval=interval, auto_adjust=False, progress=False)
    if df.empty:
        raise ValueError(f"No data for {ticker}")
    # Standardize columns
    ren = {c: str(c).title() for c in df.columns}
    df = df.rename(columns=ren)[["Open","High","Low","Close","Adj Close","Volume"]]
    df.index.name = "datetime"
    _save_parquet(df, path)
    return df

def fetch_crypto_ohlcv(symbol: str, exchange_id="binance", timeframe="1d", limit=1500, cache_ttl_min=60):
    """CCXT OHLCV for crypto (e.g., 'BTC/USDT')."""
    path = _cache_path("ohlcv_crypto", f"{exchange_id}_{symbol}_{timeframe}")
    if path.exists() and (time.time() - path.stat().st_mtime) < cache_ttl_min * 60:
        return _read_parquet(path)
    ex = getattr(ccxt, exchange_id)({"enableRateLimit": True})
    ohlcv = ex.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    if not ohlcv:
        raise ValueError(f"No data for {symbol} on {exchange_id}")
    df = pd.DataFrame(ohlcv, columns=["datetime","Open","High","Low","Close","Volume"])
    df["datetime"] = pd.to_datetime(df["datetime"], unit="ms", utc=True).dt.tz_convert(None)
    df = df.set_index("datetime").sort_index()
    _save_parquet(df, path)
    return df

def fetch_fred_series(series_id: str, fred_api_key: str, cache_ttl_min=60):
    """FRED series with Parquet cache (index: date)."""
    path = _cache_path("fred", series_id)
    if path.exists() and (time.time() - path.stat().st_mtime) < cache_ttl_min * 60:
        return _read_parquet(path)
    fred = Fred(api_key=fred_api_key)
    s = fred.get_series(series_id)
    df = s.to_frame(name=series_id).rename_axis("date").sort_index()
    _save_parquet(df, path)
    return df

def upsert_to_duckdb(df: pd.DataFrame, table: str, conn_path=DB_PATH):
    con = duckdb.connect(str(conn_path))
    con.register("tmp_df", df.reset_index())
    con.execute(f"CREATE TABLE IF NOT EXISTS {table} AS SELECT * FROM tmp_df")
    con.execute(f"DELETE FROM {table}")
    con.execute(f"INSERT INTO {table} SELECT * FROM tmp_df")
    con.close()
