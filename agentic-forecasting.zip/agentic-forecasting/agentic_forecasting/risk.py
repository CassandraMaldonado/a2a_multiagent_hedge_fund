# Risk: GARCH, VaR/ES, position sizing, kill switches
# pip install arch

import numpy as np
import pandas as pd
from arch import arch_model

def fit_garch_returns(close: pd.Series):
    r = np.log(close).diff().dropna() * 100  # percent log-returns
    am = arch_model(r, vol='Garch', p=1, q=1, dist='normal', mean='Constant')
    res = am.fit(disp="off")
    sigma = res.conditional_volatility / 100.0  # daily std of returns
    sigma.name = "garch_sigma"
    return sigma

def compute_var_es(returns: pd.Series, alpha=0.05, window=252):
    r = returns.dropna()
    var = r.rolling(window).quantile(alpha)
    es = r.rolling(window).apply(lambda x: x[x <= np.quantile(x, alpha)].mean() if len(x)>0 else np.nan, raw=False)
    var.name = f"VaR_{alpha}"; es.name = f"ES_{alpha}"
    return var, es

def vol_target_position_size(target_vol_annual=0.15, garch_sigma_daily: pd.Series=None, price_series: pd.Series=None, capital=100_000):
    if garch_sigma_daily is None:
        raise ValueError("Provide daily sigma series")
    target_daily = target_vol_annual / np.sqrt(252)
    scale = (target_daily / garch_sigma_daily).clip(upper=5.0)  # cap leverage to 5x
    px = price_series.reindex(scale.index).ffill()
    dollars = (capital * 0.95) * scale  # keep cash buffer
    units = (dollars / px).fillna(0)
    return units.rename("units")

def apply_kill_switch(equity_curve: pd.Series, max_drawdown=0.2, rolling_trades=30, min_sharpe=0.0):
    dd = (equity_curve / equity_curve.cummax() - 1.0)
    breach_dd = dd < -abs(max_drawdown)
    ret = equity_curve.pct_change().fillna(0.0)
    roll_sharpe = ret.rolling(rolling_trades).mean() / (ret.rolling(rolling_trades).std() + 1e-9) * np.sqrt(252)
    breach_sh = roll_sharpe < min_sharpe
    kill_mask = breach_dd | breach_sh
    return kill_mask.rename("kill")
