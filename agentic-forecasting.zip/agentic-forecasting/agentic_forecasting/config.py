import yaml
from dataclasses import dataclass

@dataclass
class AppConfig:
    assets: list
    horizons: list
    use_sentiment: bool = True
    use_macro: bool = True
    use_garch: bool = True
    transaction_costs_bps: int = 2
    slippage_bps: int = 10
    fred_api_key: str | None = None

def load_config(path="configs/app.yaml")->AppConfig:
    with open(path, "r") as f:
        cfg = yaml.safe_load(f)
    return AppConfig(**cfg)
