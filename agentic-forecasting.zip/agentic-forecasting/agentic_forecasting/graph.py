# LangGraph orchestration wrapping the core nodes
# pip install langgraph langchain

import pandas as pd
from typing import TypedDict
from langgraph.graph import StateGraph, END

from .data import fetch_equity_ohlcv, fetch_crypto_ohlcv, fetch_fred_series
from .features import market_features, join_with_macro_sentiment, macro_transforms
from .forecasting import walk_forward_arima
from .risk import fit_garch_returns
from .backtest import backtest_long_only
from .config import load_config

class PipeState(TypedDict, total=False):
    asset: str
    ohlcv: pd.DataFrame
    features: pd.DataFrame
    macro: pd.DataFrame
    sigma: pd.Series
    forecast: pd.Series
    recommendation: dict
    backtest_stats: dict

def node_market(state: PipeState)->PipeState:
    ohlcv = fetch_equity_ohlcv(state["asset"]) if "-" not in state["asset"] else fetch_crypto_ohlcv(state["asset"])
    feats = market_features(ohlcv)
    return {**state, "ohlcv": ohlcv, "features": feats}

def node_macro(state: PipeState)->PipeState:
    cfg = load_config()
    if not cfg.use_macro or not cfg.fred_api_key:
        return state
    cpi = fetch_fred_series("CPIAUCSL", cfg.fred_api_key)
    m = macro_transforms(cpi)
    feats = join_with_macro_sentiment(state["features"], m, None)
    return {**state, "macro": m, "features": feats}

def node_risk(state: PipeState)->PipeState:
    if not load_config().use_garch:
        return state
    sigma = fit_garch_returns(state["ohlcv"]["Close"])
    return {**state, "sigma": sigma}

def node_forecast(state: PipeState)->PipeState:
    close = state["ohlcv"]["Close"]
    wf = walk_forward_arima(close, order=(2,1,2))
    return {**state, "forecast": wf.predictions}

def node_strategy(state: PipeState)->PipeState:
    cfg = load_config()
    close = state["ohlcv"]["Close"]
    forecast = state["forecast"].reindex(close.index)
    eq, net_ret, stats = backtest_long_only(close, forecast, cost_bps=cfg.transaction_costs_bps, slippage_bps=cfg.slippage_bps)
    rec = {"position_rule": "sign(forecast)"}
    return {**state, "recommendation": rec, "backtest_stats": stats}

def build_graph():
    g = StateGraph(PipeState)
    g.add_node("market", node_market)
    g.add_node("macro", node_macro)
    g.add_node("risk", node_risk)
    g.add_node("forecast", node_forecast)
    g.add_node("strategy", node_strategy)
    g.set_entry_point("market")
    g.add_edge("market", "macro")
    g.add_edge("macro", "risk")
    g.add_edge("risk", "forecast")
    g.add_edge("forecast", "strategy")
    g.add_edge("strategy", END)
    return g.compile()
