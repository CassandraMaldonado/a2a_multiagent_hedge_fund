import numpy as np
import pandas as pd

def market_features(ohlcv: pd.DataFrame) -> pd.DataFrame:
    df = ohlcv.copy()
    df["ret_1d"] = df["Close"].pct_change()
    df["log_ret"] = np.log(df["Close"]).diff()
    df["rv_10"] = df["ret_1d"].rolling(10).std()
    # RSI(14) simplified
    up = df["ret_1d"].clip(lower=0).rolling(14).mean()
    dn = (-df["ret_1d"].clip(upper=0)).rolling(14).mean()
    rs = up / (dn + 1e-9)
    df["rsi_14"] = 100 - (100 / (1 + rs))
    # MACD + signal
    ema_fast = df["Close"].ewm(span=12, adjust=False).mean()
    ema_slow = df["Close"].ewm(span=26, adjust=False).mean()
    df["macd"] = ema_fast - ema_slow
    df["macd_sig"] = df["macd"].ewm(span=9, adjust=False).mean()
    # ATR(14)
    tr = pd.concat([
        (df["High"] - df["Low"]).abs(),
        (df["High"] - df["Close"].shift()).abs(),
        (df["Low"]  - df["Close"].shift()).abs()
    ], axis=1).max(axis=1)
    df["atr_14"] = tr.rolling(14).mean()
    return df.dropna()

def join_with_macro_sentiment(market_df: pd.DataFrame, macro_df: pd.DataFrame | None=None, sent_df: pd.DataFrame | None=None):
    out = market_df.copy()
    if macro_df is not None and not macro_df.empty:
        out = out.join(macro_df, how="left")
    if sent_df is not None and not sent_df.empty:
        out = out.join(sent_df, how="left")
    return out.dropna()

def macro_transforms(cpi: pd.DataFrame | pd.Series | None=None):
    if cpi is None:
        return pd.DataFrame()
    df = cpi.to_frame() if isinstance(cpi, pd.Series) else cpi.copy()
    for col in df.columns:
        df[f"{col}_mom"] = df[col].pct_change()
        df[f"{col}_yoy"] = df[col].pct_change(12)
    return df.dropna()
