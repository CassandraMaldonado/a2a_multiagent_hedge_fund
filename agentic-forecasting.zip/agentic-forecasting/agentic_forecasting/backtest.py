import numpy as np
import pandas as pd

def backtest_long_only(close: pd.Series, signal_ret_pred: pd.Series, cost_bps=2, slippage_bps=5):
    """Simple sign-of-forecast strategy with costs and slippage."""
    signal = np.sign(signal_ret_pred).reindex(close.index).fillna(0)
    pos = signal.shift().fillna(0)
    ret = close.pct_change().fillna(0)
    gross = pos * ret
    turns = pos.diff().abs().fillna(0)
    tc = turns * (cost_bps + slippage_bps) / 1e4
    net = gross - tc
    eq = (1 + net).cumprod()
    stats = {
        "CAGR": (eq.iloc[-1]) ** (252/len(eq)) - 1 if len(eq)>0 else np.nan,
        "Sharpe": net.mean() / (net.std()+1e-9) * np.sqrt(252),
        "Sortino": net.mean() / (net[net<0].std()+1e-9) * np.sqrt(252),
        "MaxDD": float((eq/eq.cummax()-1).min()),
        "HitRate": float((np.sign(net)==1).mean()),
        "Turnover": float(turns.mean()*252)
    }
    return eq, pd.Series(net, index=close.index, name="net_ret"), stats

def attribute_performance(net_ret: pd.Series, features: pd.DataFrame):
    X = (features - features.mean()) / (features.std() + 1e-9)
    y = net_ret.loc[X.index]
    X = X.dropna(); y = y.loc[X.index]
    coef = pd.Series(np.linalg.lstsq(X.values, y.values, rcond=None)[0], index=X.columns, name="coef")
    return coef.sort_values(ascending=False)
