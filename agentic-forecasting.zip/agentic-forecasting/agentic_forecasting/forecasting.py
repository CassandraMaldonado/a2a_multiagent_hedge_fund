# Forecasting: ARIMA baseline, Prophet optional, LSTM optional
# pip install statsmodels prophet tensorflow

import numpy as np
import pandas as pd
from typing import Dict, List
from dataclasses import dataclass
from statsmodels.tsa.arima.model import ARIMA
try:
    from prophet import Prophet
    _HAS_PROPHET = True
except Exception:
    _HAS_PROPHET = False

import tensorflow as tf
from tensorflow.keras import layers, models

@dataclass
class WFResult:
    fold_metrics: List[Dict]
    predictions: pd.Series

def walk_forward_arima(close: pd.Series, order=(2,1,2), horizon=1, train_years=3, test_months=3) -> WFResult:
    idx = close.dropna().index
    start = idx.min() + pd.DateOffset(years=train_years)
    preds = []
    metrics = []
    t = start
    while t < idx.max():
        train_end = t
        test_end = min(t + pd.DateOffset(months=test_months), idx.max())
        tr = close.loc[:train_end].dropna()
        te = close.loc[train_end:test_end].dropna()
        if len(tr) < 50 or len(te) < 5:
            t += pd.DateOffset(months=1); continue
        model = ARIMA(np.log(tr), order=order).fit()
        fc = model.forecast(steps=len(te))
        fc = np.exp(fc); fc.index = te.index
        pr = fc.pct_change().reindex(te.index)
        preds.append(pr)
        y = te.pct_change().reindex(pr.index)
        mae = (y - pr).abs().mean()
        rmse = np.sqrt(((y - pr)**2).mean())
        metrics.append({"train_end": str(train_end), "test_end": str(test_end), "MAE": float(mae), "RMSE": float(rmse)})
        t += pd.DateOffset(months=1)
    pred_series = pd.concat(preds).sort_index()
    return WFResult(metrics, pred_series)

def walk_forward_prophet(close: pd.Series, horizon_days=1, train_years=3, test_months=3) -> WFResult:
    if not _HAS_PROPHET:
        raise RuntimeError("Prophet not installed")
    close = close.dropna()
    df = close.reset_index().rename(columns={close.index.name or "index":"ds", close.name or 0:"y"})
    preds, metrics = [], []
    start = df["ds"].min() + pd.DateOffset(years=train_years)
    t = start
    while t < df["ds"].max():
        tr = df[df["ds"]<=t]
        te = df[(df["ds"]>t) & (df["ds"]<=t+pd.DateOffset(months=test_months))]
        if len(tr)<100 or len(te)<5:
            t += pd.DateOffset(months=1); continue
        m = Prophet(daily_seasonality=True, weekly_seasonality=True)
        m.fit(tr)
        future = pd.DataFrame({"ds": te["ds"]})
        fc = m.predict(future)[["ds","yhat"]].set_index("ds")["yhat"]
        pr = fc.pct_change()
        y = df.set_index("ds")["y"].loc[pr.index].pct_change()
        mae = (y - pr).abs().mean(); rmse = np.sqrt(((y - pr)**2).mean())
        preds.append(pr)
        metrics.append({"train_end": str(t), "test_end": str(t+pd.DateOffset(months=test_months)), "MAE": float(mae), "RMSE": float(rmse)})
        t += pd.DateOffset(months=1)
    return WFResult(metrics, pd.concat(preds).sort_index())

def build_lstm(input_dim:int, lookback:int=60):
    model = models.Sequential([
        layers.Input(shape=(lookback, input_dim)),
        layers.LSTM(64, return_sequences=True),
        layers.Dropout(0.2),
        layers.LSTM(32),
        layers.Dense(1)
    ])
    model.compile(optimizer="adam", loss="mse")
    return model

def prepare_lstm_xy(df: pd.DataFrame, target_col: str="ret_1d", lookback:int=60):
    X, y = [], []
    values = df.values
    tgt = df[target_col].values
    for i in range(lookback, len(df)):
        X.append(values[i-lookback:i, :])
        y.append(tgt[i])
    import numpy as np
    return np.array(X, dtype=np.float32), np.array(y, dtype=np.float32)

def walk_forward_lstm(features: pd.DataFrame, lookback=60, epochs=20, batch_size=32) -> WFResult:
    features = features.dropna().copy()
    preds = pd.Series(index=features.index, dtype=float)
    metrics = []
    months = sorted(set(pd.PeriodIndex(features.index, freq='M')))
    if len(months) < 7:
        raise ValueError("Not enough data for walk-forward LSTM.")
    for k in range(6, len(months)-1):
        train_end = months[k].end_time
        test_end = months[k+1].end_time
        tr = features.loc[:train_end]
        te = features.loc[train_end:test_end]
        if len(tr) < 300 or len(te) < 10:
            continue
        Xtr, ytr = prepare_lstm_xy(tr, "ret_1d", lookback)
        Xte, yte = prepare_lstm_xy(pd.concat([tr.tail(lookback), te]), "ret_1d", lookback)
        model = build_lstm(input_dim=features.shape[1], lookback=lookback)
        model.fit(Xtr, ytr, epochs=epochs, batch_size=batch_size, verbose=0)
        pr = model.predict(Xte, verbose=0).flatten()
        idx = te.index[lookback:]
        preds.loc[idx] = pr
        import numpy as np
        mae = np.mean(np.abs(yte - pr)); rmse = np.sqrt(np.mean((yte - pr)**2))
        metrics.append({"train_end": str(train_end), "test_end": str(test_end), "MAE": float(mae), "RMSE": float(rmse)})
    return WFResult(metrics, preds.dropna())
